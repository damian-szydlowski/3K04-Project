# Main File for DCM
from controller import DCMApp

if __name__ == "__main__":
    app = DCMApp()
    app.mainloop()